collection=$1
feature=$2
rootpath=$3
overwrite=$4

python util/get_frameInfo.py  --collection $collection --feature $feature --rootpath $rootpath --overwrite $overwrite