# Dual LSTM Encoder for ranking short texts

## Requirements
* Tensorflow 1.0
* Numpy
