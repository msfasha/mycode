
nocontext_model = "https://github.com/davidalami/ConveRT/releases/download/1.0/nocontext_tf_model.tar.gz"
multicontext_model = "https://github.com/davidalami/ConveRT/releases/download/1.0/multicontext_tf_model.tar"