collection=$1
feature=$2

python util/get_frameInfo.py  --collection $collection --feature $feature 