=================================================================
=================================================================
                    MADAR Parallel Corpora

                        Release of Data
                        8 November 2019

================================================================
Copyright (c) 2019 Carnegie Mellon University Qatar and New York
University Abu Dhabi. All rights reserved.
=================================================================
=================================================================
Summary
=================================================================
The MADAR corpus is a collection of parallel sentences covering
the dialects of 25 cities from the Arab World, in addition to
English, French, and MSA. The corpus is created by translating
selected sentences from the Basic Traveling Expression Corpus
(BTEC) (Takezawa et al., 2007) to the different dialects.
The exact details on the translation process and source and
target languages are described in Bouamor et al. (2018).

The list of Arab cities covered in the MADAR corpus includes:
Aleppo, Alexandria, Algiers, Amman, Aswan, Baghdad, Basra, Beirut,
Benghazi, Cairo, Damascus, Doha, Fes, Jeddah, Jerusalem, Khartoum,
Mosul, Muscat, Rabat, Riyadh, Salt, Sanaa, Sfax, Tripoli,
and Tunis.

This release contains two datasets:

* Corpus-26: a set of 2,000 BTEC sentences and translated to
all 25 city dialects (each of these sentences has 25 corresponding
parallel translations), in addition to MSA.

* Corpus-6: a set of 12,000 sentences translated to the dialects
of five selected cities: Doha, Beirut, Cairo, Tunis, and Rabat,
in addition to MSA.

Note: We do not provide the English or the French versions of the
corpus because of copyright restrictions. In order to get access to
the English corpus, you will have to contact NICT and the U-Star
Consortium (Prof. Eiichiro Sumita, eiichiro.sumita@nict.go.jp) to
obtain an end-user agreement that you will have to sign.  The current
contacts for the French version can also be obtained from the U-Star
Consortium.

When citing this resource, please use:

Bouamor, Houda, Nizar Habash, Mohammad Salameh, Wajdi Zaghouani,
Owen Rambow, Dana Abdulrahim, Ossama Obeid, Salam Khalifa,
Fadhl Eryani, Alexander Erdmann and Kemal Oflazer.
The MADAR Arabic Dialect Corpus and Lexicon.
In Proceedings of the International Conference on Language
Resources and Evaluation (LREC 2018), Miyazaki, Japan, 2018.

@inproceedings{Bouamor:2018:madar,
  Address = {Miyazaki, Japan},
  Author = {Houda Bouamor and Nizar Habash and Mohammad Salameh and
  Wajdi Zaghouani and Owen Rambow and Dana Abdulrahim and Ossama
  Obeid and Salam Khalifa and Fadhl Eryani and Alexander Erdmann
   and Kemal Oflazer},
  Booktitle = {Proceedings of the Language Resources and Evaluation
  Conference (LREC)},
  Title = {{The MADAR {A}rabic Dialect Corpus and Lexicon}},
  Year = {2018}}

=================================================================
MADAR Corpus
=================================================================

Description of Data:
--------------------

The folder contains two sub-folders and two files:

* MADAR.Corpus-6: this folder contains 7 files, containing each
a set of 12,000 sentences for each dialect/language. 2,000 sentences
in this corpus overlap with the 2,000 sentences in MADAR.Corpus-26
for MSA, Beirut, Cairo, Doha, Rabat, and Tunis.

  - MADAR.corpus6.MSA
  - MADAR.corpus6.Beirut
  - MADAR.corpus6.Cairo
  - MADAR.corpus6.Doha
  - MADAR.corpus6.Rabat
  - MADAR.corpus6.Tunis
  - MADAR.corpus6.sentID.BTEC

The MADAR.corpus6.sentID.BTEC file corresponds to the sentence line
number in the original English and French BTEC files.

* MADAR.Corpus-26: this folder contains 27 files, containing each a
set of 2,000 sentences for each dialect/language. The 2,000 sentences
for MSA, Beirut, Cairo, Doha, Rabat, and Tunis overlap with 2,000
sentences in MADAR.Corpus-6.

  - MADAR.corpus26.Aleppo
  - MADAR.corpus26.Alexandria
  - MADAR.corpus26.Algiers
  - MADAR.corpus26.Amman
  - MADAR.corpus26.Aswan
  - MADAR.corpus26.Baghdad
  - MADAR.corpus26.Basra
  - MADAR.corpus26.Beirut
  - MADAR.corpus26.Benghazi
  - MADAR.corpus26.Cairo
  - MADAR.corpus26.Damascus
  - MADAR.corpus26.Doha
  - MADAR.corpus26.Fes
  - MADAR.corpus26.Jeddah
  - MADAR.corpus26.Jerusalem
  - MADAR.corpus26.Khartoum
  - MADAR.corpus26.MSA
  - MADAR.corpus26.Mosul
  - MADAR.corpus26.Muscat
  - MADAR.corpus26.Rabat
  - MADAR.corpus26.Riyadh
  - MADAR.corpus26.Salt
  - MADAR.corpus26.Sanaa
  - MADAR.corpus26.Sfax
  - MADAR.corpus26.Tripoli
  - MADAR.corpus26.Tunis
  - MADAR.corpus26.sentID.BTEC

The MADAR.corpus26.sentID.BTEC file corresponds to the sentence line
number in the original English and French BTEC files.

* README.txt
* LICENSE.txt
=================================================================
References
=================================================================

[1] Bouamor, Houda, Nizar Habash, Mohammad Salameh, Wajdi Zaghouani,
Owen Rambow, Dana Abdulrahim, Ossama Obeid, Salam Khalifa, Fadhl
Eryani, Alexander Erdmann and Kemal Oflazer.  "The MADAR Arabic
Dialect Corpus and Lexicon."  Proceedings of the Eleventh
International Conference on Language Resources and Evaluation (LREC
2018). Miyazaki, Japan, 2018.
http://www.lrec-conf.org/proceedings/lrec2018/pdf/351.pdf

[2] Takezawa, Toshiyuki, Genichiro Kikui, Masahide Mizushima, and
Eiichiro Sumita. 2007. Multilingual Spoken Language Corpus Development
for Communication Research. Computational Linguistics and Chinese
Language Processing, 12(3):303–324.

================================================================
Copyright (c) 2019 Carnegie Mellon University Qatar and New York
University Abu Dhabi. All rights reserved.
================================================================
